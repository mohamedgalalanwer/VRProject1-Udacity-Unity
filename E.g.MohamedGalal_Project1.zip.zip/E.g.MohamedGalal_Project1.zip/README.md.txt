Myname:MohamedGalalAnwer

It took 15 minutes

i like the  button changes , toggle Sun and when i using the vr in my phone 


challenging in complete the task in a short time


fileFormatVersion: 2

VRND Course 1 Starter Project (version 5)
GoogleVR Unity SDK (v 1.0.3)
 
